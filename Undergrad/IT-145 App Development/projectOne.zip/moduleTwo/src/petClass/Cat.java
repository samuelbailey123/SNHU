package petClass;

//@author Samuel Bailey
public class Cat extends Pet{
    public int catSpaceNbr;
}
