package petClass;

//@author Samuel Bailey
public class Cat extends Pet{
    private int catSpaceNbr;
}
