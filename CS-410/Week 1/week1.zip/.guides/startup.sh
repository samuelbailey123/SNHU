#!/bin/bash
startxfce4

