#include<iostream>
using namespace std;

int main()
     {
 int width=10;
 int height=5;
 int area;
 area = width * height;
 
cout<<endl<< area;
 return 0;
}
